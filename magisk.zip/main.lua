-- fas-rs 使用它来提供指定版本的api
-- fas-rs use this to provide version-specified api
API_VERSION = 4
--
-- 中文:
-- 该枚举对应的lua函数
-- 在 fas-rs 中将被 fas-rs 回调
-- pub enum Api {
--  LoadFas(pid_t, String), --------> function load_fas(pid, pkg)
--  UnloadFas(pid_t, String), ------> function unload_fas(pid, pkg)
--  StartFas, ----------------------> function start_fas()
--  StopFas, -----------------------> function stop_fas()
--  InitCpuFreq, -------------------> function init_cpu_freq()
--  ResetCpuFreq, ------------------> function reset_cpu_freq()
--  TargetFpsChange(u32, String) ---> function target_fps_change(target_fps, pkg)
-- }
--
-- 可注册的函数说明:
-- function load_fas(pid, pkg)
-- 当 fas-rs 加载到目标游戏时调用，
-- 参数为目标应用程序的pid和包名
--
-- function unload_fas(pid, pkg)
-- 当 fas-rs 卸载到目标游戏时调用，
-- 参数为目标应用程序的pid和包名
--
-- function start_fas()
-- 切换到fas-rs工作状态时调用。
--
-- function stop_fas()
-- 切换到 fas-rs 不工作状态时调用。
--
-- function init_cpu_freq()
-- 当cpu控制器进入控制状态时调用。
--
-- function reset_cpu_freq()
-- 当cpu控制器退出控制状态时调用。
--
-- target_fps_change(target_fps, pkg)
-- 当fas目标帧率改变时调用
--
-- 附加: 在函数外的lua代码会在插件加载时被执行，
-- 如果你有执行初始化内容的需求，这样做很方便。
--
-- fas-rs提供的函数:
-- log_info("message")
-- 打印一个info等级日志到/sdcard/Android/fas-rs/fas_log.txt
--
-- log_error("message")
-- 打印一个error等级日志到/sdcard/Android/fas-rs/fas_log.txt
--
-- log_debug("message")
-- 打印一个debug等级日志到/sdcard/Android/fas-rs/fas_log.txt，
-- 此等级在fas-rs的release build不开启
--
-- set_extra_policy_abs(policy, min_freq, max_freq)
-- 设置指定集群的频率范围(频率为绝对值)限制，min_freq和max_freq为频率值，单位khz
--
-- set_extra_policy_rel(policy, target_policy, min_freq, max_freq)
-- 设置指定集群的频率范围(频率为相对值)限制，target_policy为相对值的目标集群，
-- min_freq和max_freq为相对频率值(范围计算方式:目标集群频率 + min_freq <= 指定集群频率 <= 目标集群频率 + max_freq)，单位khz
--
-- remove_extra_policy(policy)
-- 移除指定集群的额外频率限制(由set_extra_policy_abs或set_extra_policy_rel设置)
-- 注意游戏退出后限制不会自动移除，因此你应该在unload_fas回调中手动移除限制
--
-- set_ignore_policy(policy, val)
-- 设置是否对指定集群开启fas频率控制，val为bool
--
-- ------------------------------------
--
-- EN:
-- The lua function corresponding to this enumeration
-- in fas-rs will be called back by fas-rs
-- pub enum Api {
--  LoadFas(pid_t, String), --------> function load_fas(pid, pkg)
--  UnloadFas(pid_t, String), ------> function unload_fas(pid, pkg)
--  StartFas, ----------------------> function start_fas()
--  StopFas, -----------------------> function stop_fas()
--  InitCpuFreq, -------------------> function init_cpu_freq()
--  ResetCpuFreq, ------------------> function reset_cpu_freq()
--  TargetFpsChange(u32, String) ---> function target_fps_change(target_fps, pkg)
-- }
--
-- Registerable function description:
-- function load_fas(pid, pkg)
-- Called when fas-rs is loaded into the target game,
-- The parameters are the pid and package name of the target application
--
-- function unload_fas(pid, pkg)
-- Called when fas-rs is unloaded to the target game,
-- The parameters are the pid and package name of the target application
--
-- function start_fas()
-- Called when switching to fas-rs working state.
--
-- function stop_fas()
-- Called when switching to fas-rs not-working state.
--
-- function init_cpu_freq()
-- Called when the cpu controller enters the control state.
--
-- function reset_cpu_freq()
-- Called when the cpu controller exits the control state.
--
-- target_fps_change(target_fps, pkg)
-- Called when target fps changes.
--
-- Extra: Lua code outside the function will be
-- executed when the extension is loaded, if you need to
-- execute initialization content, this is convenient.
--
-- Functions provided by fas-rs:
-- log_info("message")
-- Print an info level log to /sdcard/Android/fas-rs/fas_log.txt
--
-- log_error("message")
-- Print an error level log to /sdcard/Android/fas-rs/fas_log.txt
--
-- log_debug("message")
-- Print a debug level log to /sdcard/Android/fas-rs/fas_log.txt,
-- This level is not enabled in the release build of fas-rs.
--
-- set_policy_freq_offset(policy, offset)
-- Sets the FAS frequency offset for the specified cluster, which can be a negative number.
--
-- set_extra_policy_abs(policy, min_freq, max_freq)
-- Sets the frequency range limit (frequency is an absolute value) for the specified cluster,
-- min_freq and max_freq are frequency values, in khz
--
-- set_extra_policy_rel(policy, target_policy, min_freq, max_freq)
-- Sets the frequency range limit (frequency is a relative value) for the specified cluster,
-- target_policy is the target cluster of the relative value, min_freq and max_freq are relative frequency values,
-- (range calculation method: target cluster frequency + min_freq <= specified cluster frequency <= target cluster frequency + max_freq),
-- in khz
--
-- remove_extra_policy(policy)
-- Removes the extra frequency limit (set by set_extra_policy_abs or set_extra_policy_rel) for the specified cluster
-- Note that the limit will not be automatically removed after the game exits, so you should manually remove the limit in the unload_fas callback
--
-- set_ignore_policy(policy, val)
-- Sets whether to enable FAS frequency control for the specified cluster, val is a bool.
--

local kfas_hook = "/sys/module/pandora_kfas/parameters/kfas_hook"

function lock_val(path, val)
    os.execute("chmod 644 " .. path)
    local file = io.open(path, "w")
    file:write(val)
    file:flush()
    file:close()
    os.execute("chmod 444 " .. path)
end

function unlock_val(path, val)
    os.execute("chmod 644 " .. path)
    local file = io.open(path, "w")
    file:write(val)
    file:flush()
    file:close()
end

function load_fas(pid, pkg)
    lock_val(kfas_hook, "1")
end

function stop_fas(pid, pkg)
    unlock_val(kfas_hook, "0")
end
