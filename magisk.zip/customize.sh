#!/system/bin/sh

uninstall_old_module() {
    MODULE_ID="$1"
    CUR_PWD="$PWD"
    cd "/data/adb/modules/$MODULE_ID" || return
    ui_print "- Cleanup old module"
    PROPS="$(awk '/^persist\./ {sub(/=.*/, ""); print}' "/data/adb/modules/$MODULE_ID/system.prop")"
    sh "/data/adb/modules/$MODULE_ID/uninstall.sh" wait >/dev/null 2>&1
    for prop in $PROPS; do
        resetprop -p --delete "$prop"
    done
    cd "$CUR_PWD" || return
}

uninstall_old_module "haruhi_kernel"
uninstall_old_module "$(grep_prop id "$MODPATH/module.prop")"

set_perm_recursive "$MODPATH/bin" 0 0 0755 0755
set_perm_recursive "$MODPATH/system/vendor/etc" 0 0 0755 0644 u:object_r:vendor_configs_file:s0

if [ -n "$(which magisk)" ]; then
    magisk --sqlite "insert or replace into settings values ('mnt_ns', 0)"
fi

VENDOR="$(getprop ro.hardware)"
if [ "$VENDOR" = "qcom" ]; then
    ui_print "- Qualcomm device"
    cat "$MODPATH/qcom.prop" >>"$MODPATH/system.prop"
    PERFBOOST_ROOT="/vendor/etc/perf"
    mkdir -p "$MODPATH/system/$PERFBOOST_ROOT"
    for file in perfboostsconfig.xml perfboostselection.xml; do
        sed "s#Enable=\"true\"#Enable=\"false\"#g" "$PERFBOOST_ROOT/$file" >"$MODPATH/system/$PERFBOOST_ROOT/$file"
    done
    rm -rf "$MODPATH/system/vendor/etc/power_app_cfg.xml"
    rm -rf "$MODPATH/system/vendor/etc/powerscntbl.xml"
    rm -rf "$MODPATH/system/vendor/etc/powercontable.xml"
else
    ui_print "- MTK device"
    cat "$MODPATH/mtk.prop" >>"$MODPATH/system.prop"
fi
rm -rf "$MODPATH/qcom.prop" "$MODPATH/mtk.prop"

if [ -d "/my_product" ] || [ -d "/mnt/vendor/my_product" ]; then
    ui_print "- OPLUS device"
    cat "$MODPATH/oplus.prop" >>"$MODPATH/system.prop"
    if [ "$VENDOR" = "qcom" ]; then
        ui_print "- OPLUS Qualcomm device"
        cat "$MODPATH/oplus_qcom.prop" >>"$MODPATH/system.prop"
    else
        ui_print "- OPLUS MTK device"
        cat "$MODPATH/oplus_mtk.prop" >>"$MODPATH/system.prop"
    fi
fi

rm -rf "$MODPATH/oplus.prop" "$MODPATH/oplus_qcom.prop" "$MODPATH/oplus_mtk.prop"

find "$MODPATH" -type d -empty -delete
