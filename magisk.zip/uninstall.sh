#!/system/bin/sh

MODDIR=${0%/*}
PROPS="$(awk '/^persist\./ {sub(/=.*/, ""); print}' "$MODDIR/system.prop")"

wait_until_login() {
    # in case of /data encryption is disabled
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 1
    done

    # in case of the user unlocked the screen
    until [ -d "/data/data/android" ]; do
        sleep 1
    done
}

exec_system() {
    eval "$1" </dev/null 2>&1 | cat
}

remove_persist_props() {
    for prop in $PROPS; do
        resetprop -p --delete "$prop"
    done
}

uninstall_module() {
    exec_system "device_config delete activity_manager max_cached_processes"
    exec_system "device_config delete activity_manager max_phantom_processes"
    exec_system "device_config delete netd_native happy_eyeballs_enable"
    exec_system "device_config delete netd_native parallel_lookup"
    exec_system "device_config delete netd_native sort_nameservers"
    exec_system "device_config delete runtime_native_boot enable_uffd_gc_2"
    exec_system "device_config delete runtime_native_boot disable_lock_profiling"
    exec_system "device_config delete lmkd_native use_minfree_levels"
    exec_system "device_config set_sync_disabled_for_tests none"
    exec_system "pm enable com.oplus.athena/com.oplus.athena.client.AthenaService"
    exec_system "am force-stop com.oplus.athena"
    exec_system "settings delete global settings_enable_monitor_phantom_procs"
}

remove_persist_props
if [ "$1" = "wait" ]; then
    uninstall_module
else
    {
        rm -rf /data/dalvik-cache/*
        wait_until_login
        uninstall_module
    } &
fi
