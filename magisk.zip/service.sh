#!/system/bin/sh

MODDIR=${0%/*}
USE_THP="$(awk 'NR==1{if (int($2/1024/1024) < 10) print "false";else print "true";}' </proc/meminfo)"

. "$MODDIR/utils.sh"

init_node_mtk() {
    set_governor "schedutil"

    mask_val_in_path "0" /sys/kernel/fpsgo/fbt "limit_*freq*"
    mask_val "0" /sys/kernel/fpsgo/fbt/enable_ceiling
    mask_val "1" /sys/kernel/fpsgo/common/force_onoff
    mask_val "1" /sys/kernel/fpsgo/common/fpsgo_enable
    mask_val "0" /sys/kernel/ged/hal/custom_upbound_gpu_freq
    mask_val "1" /sys/module/ged/parameters/is_GED_KPI_enabled
    mask_val "0" /sys/module/mtk_core_ctl/parameters/policy_enable
    mask_val "0" "/sys/module/mtk_game/parameters/engine_cooler_enable"
    mask_val "TTJ 105000 105000 105000" /sys/kernel/thermal/ttj
    mask_val "MAX_TTJ 105000 105000 105000" /sys/kernel/thermal/max_ttj
    mask_val "MIN_TTJ 105000" /sys/kernel/thermal/min_ttj
    mask_val "1" /sys/kernel/thermal/sports_mode
    mask_val "1" /sys/kernel/thermal/cg_policy_mode
    lock_val "0" /sys/kernel/ged/hal/dcs_mode

    for i in 3 4 7 8 9; do
        mask_val "switch $i 0 0" "/proc/gpufreqv2/limit_table"
    done

    mask_val "1" /proc/mtk_lpm/cpuidle/enable
    mask_val "0" /proc/mtk_lpm/cpuidle/cpu_pf_en
    mask_val "1" /proc/mtk_lpm/cpuidle/cpu_ret_en

    for svc in power-hal-1-0 vendor.mtkpower_service.mediatek vendor.mtkpower_applist-default; do
        stop $svc
    done

    for svc in power-hal-1-0 vendor.mtkpower_service.mediatek vendor.mtkpower_applist-default; do
        start $svc
    done

    lock_val "0" /proc/oplus_slc/disable
    lock_val "0" /proc/oplus_slc/disable_cdwb
    mask_val "0" /proc/oplus_slc/disable_cdwb
    lock_val "1,100" /proc/oplus_slc/force_ratio
    lock_val "2,100" /proc/oplus_slc/force_ratio
    mask_val "cpu_ratio 100 ; gpu_ratio 100" /proc/oplus_slc/force_ratio
}

init_node_qcom() {
    set_governor walt

    BUS_DIR="/sys/devices/system/cpu/bus_dcvs"
    lock_val_in_path "0" "$BUS_DIR" "min_freq"
    lock_val_in_path "0" "$BUS_DIR" "boost_freq"
    lock_val_in_path "1" "$BUS_DIR/DDRQOS" "boost_freq"

    lock_val "0" /sys/devices/system/cpu/dmof/disable_memcpy_optimization
    lock_val "0" /sys/devices/platform/qcom-dmof/disable_memcpy_optimization
    lock_val_in_path "0" "/sys/devices/system/cpu/cpufreq" "hispeed_freq"
    lock_val_in_path "0" "/sys/devices/system/cpu/cpufreq" "rtg_boost_freq"
    lock_val_in_path "0" "/sys/devices/system/cpu/cpufreq" "target_loads"
    lock_val_in_path "0" "/sys/devices/system/cpu/cpufreq" "pl"

    lock_val_in_path "1000" "/sys/devices/system/cpu/cpufreq" "up_rate_limit_us"
    lock_val_in_path "1000" "/sys/devices/system/cpu/cpufreq" "down_rate_limit_us"

    # [ ! -d "$MODDIR/../adreno_limiter" ] &&
    #     nohup "$MODDIR/bin/AdrenoLimiter" >/dev/null 2>&1 &

    NUM_PWRLVL="$(cat /sys/class/kgsl/kgsl-3d0/num_pwrlevels)"
    MIN_PWRLVL="$((NUM_PWRLVL - 1))"
    lock_val "2147483647" /sys/class/devfreq/*kgsl-3d0/max_freq
    lock_val "0" /sys/class/devfreq/*kgsl-3d0/min_freq
    lock_val "2147483647" /sys/class/kgsl/kgsl-3d0/max_gpu_clk
    lock_val "2147483647" /sys/class/kgsl/kgsl-3d0/max_clock_mhz
    lock_val "0" /sys/class/kgsl/kgsl-3d0/min_clock_mhz
    lock_val "$MIN_PWRLVL" /sys/class/kgsl/kgsl-3d0/default_pwrlevel
    lock_val "$MIN_PWRLVL" /sys/class/kgsl/kgsl-3d0/min_pwrlevel
    lock_val "0" /sys/class/kgsl/kgsl-3d0/max_pwrlevel
    lock_val "0" /sys/class/kgsl/kgsl-3d0/thermal_pwrlevel
    lock_val "0" /sys/class/kgsl/kgsl-3d0/throttling
    lock_val "0" /sys/class/kgsl/kgsl-3d0/force_bus_on
    lock_val "0" /sys/class/kgsl/kgsl-3d0/force_clk_on
    lock_val "0" /sys/class/kgsl/kgsl-3d0/force_no_nap
    lock_val "0" /sys/class/kgsl/kgsl-3d0/force_rail_on
    # lock_val "0" /sys/class/kgsl/kgsl-3d0/preemption
    lock_val "0" /sys/class/kgsl/kgsl-3d0/bcl
    lock_val "0" /sys/class/kgsl/kgsl-3d0/cxl
    lock_val "100" /sys/class/kgsl/kgsl-3d0/devfreq/mod_percent
    [ ! -d "$MODDIR/../adreno_limiter" ] &&
        lock_val "2147483647" /sys/kernel/gpu/gpu_max_clock
    lock_val "0" /sys/kernel/gpu/gpu_min_clock

    lock_perfhal "100000" "9999999"

    for i in /sys/class/thermal/t*; do
        grep -Eq "cpu|gpu" "$i/type" &&
            lock_val_in_path "100000" "$i" "trip_point_2_temp"
    done

    mask_val_in_path "0" "/proc/sys/walt/input_boost" "*"
    mask_val "libunity.so,libfb.so,libflutter.so,libapp.so" /proc/sys/walt/sched_lib_name
    mask_val_in_path "0" "/sys/devices/system/cpu/qcom_lpm" "*disable*"

    mask_val_in_path "gear=0" "/config/platform_mpam/slc/apps" "schemata"
    mask_val "gear=0" "/config/platform_mpam/slc/gpu/schemata"
    mask_val "cmax=100,cpbm=0xfff;prio=99;slc_partid=1" /config/qcom_mpam/default/schemata
}

init_platform_config() {
    if [ "$(getprop ro.hardware)" = "qcom" ]; then
        init_node_qcom
    else
        init_node_mtk
    fi

    disable_corectl
    lock_val_in_path "2147483647" "/sys/devices/system/cpu/cpufreq" "scaling_max_freq"

    rmdir /dev/cpuset/foreground/boost /dev/cpuset/background/untrusted

    LITTLE_LIST="$(cat /sys/devices/system/cpu/cpu0/topology/cluster_cpus_list)"
    ALL_LIST="$(cat /sys/devices/system/cpu/present)"
    lock_val "$LITTLE_LIST" /dev/cpuset/background/cpus
    lock_val "$ALL_LIST" /dev/cpuset/system-background/cpus
    lock_val "$ALL_LIST" /dev/cpuset/foreground/cpus
    lock_val "$ALL_LIST" /dev/cpuset/top-app/cpus
    lock_val "$LITTLE_LIST" /proc/irq/default_smp_affinity
    lock_val_in_path "$LITTLE_LIST" "/proc/irq" "smp_affinity_list"

    lock_val "0" /sys/kernel/rcu_expedited
    mask_val "4" /proc/sys/kernel/sched_pelt_multiplier

    mkdir -p /dev/pandora/debugfs
    mount -t debugfs none /dev/pandora/debugfs
    echo "5000000" >/dev/pandora/debugfs/sched/migration_cost_ns
    echo "10000000" >"/dev/pandora/debugfs/sched/base_slice_ns"

    for sd in /sys/block/*; do
        lock_val "none" "$sd/queue/scheduler"
        lock_val "0" "$sd/queue/iostats"
        lock_val "2" "$sd/queue/nomerges"
        lock_val "128" "$sd/queue/read_ahead_kb"
        lock_val "128" "$sd/bdi/read_ahead_kb"
    done

    for i in vendor.cnss_diag vendor.tcpdump thermal-engine cnss-daemon; do
        stop $i
    done
}

init_oplus_config() {
    lock_val "1000" "/proc/oplus-votable/GAUGE_UPDATE/force_val"
    lock_val "1" "/proc/oplus-votable/GAUGE_UPDATE/force_active"
    lock_val "0" "/proc/task_overload/skip_goplus_enabled"

    mask_val "0" "/proc/oplus_scheduler/sched_assist/sched_assist_enabled"
    mask_val "1" "/proc/game_opt/disable_cpufreq_limit"
    mask_val "1" /proc/game_opt/skip_gameself_setaffinity
    mask_val "0" "/sys/module/cpufreq_bouncing/parameters/enable"
    mask_val "0" /sys/devices/platform/soc/soc:oplus-omrg/oplus-omrg0/ruler_enable

    for svc in thermal-engine oplus_compact_memory; do
        stop $svc
    done

    exec_system "dumpsys osensemanager proc debug feature 0"
    exec_system "dumpsys osensemanager memory resrelease switch 0"
}

init_brand_specific_config() {
    init_oplus_config
}

init_zram_per() {
    swapoff "/dev/block/zram$1"
    lock_val "1" "/sys/class/block/zram$1/reset"
    lock_val "0" "/sys/class/block/zram$1/mem_limit"
    lock_val "$2" "/sys/class/block/zram$1/comp_algorithm"
    lock_val "$(awk 'NR==1{print $2*2048}' </proc/meminfo)" "/sys/class/block/zram$1/disksize"
    mkswap "/dev/block/zram$1"
    /system/bin/swapon "/dev/block/zram$1"
    rm "/dev/block/zram$1"
    touch "/dev/block/zram$1"
}

init_zram() {
    grep -q zram /proc/swaps && return

    init_zram_per "0" "zstd"
}

init_thp() {
    lock_val "always" /sys/kernel/mm/transparent_hugepage/enabled
    if [ "$USE_THP" = "false" ]; then
        lock_val "madvise" /sys/kernel/mm/transparent_hugepage/enabled
    fi
    lock_val "defer+madvise" /sys/kernel/mm/transparent_hugepage/defrag
    lock_val "within_size" /sys/kernel/mm/transparent_hugepage/shmem_enabled
    for size in 16 32 64 128 256 512 1024 2048; do
        lock_val "inherit" /sys/kernel/mm/transparent_hugepage/hugepages-"$size"kB/enabled
    done
    lock_val "0" /sys/kernel/mm/transparent_hugepage/use_zero_page
    lock_val "100" /sys/kernel/mm/transparent_hugepage/khugepaged/alloc_sleep_millisecs
    lock_val "1" /sys/kernel/mm/transparent_hugepage/khugepaged/defrag
    lock_val "8" /sys/kernel/mm/transparent_hugepage/khugepaged/max_ptes_none
    lock_val "64" /sys/kernel/mm/transparent_hugepage/khugepaged/max_ptes_swap
    lock_val "511" /sys/kernel/mm/transparent_hugepage/khugepaged/max_ptes_shared
    lock_val "65536" /sys/kernel/mm/transparent_hugepage/khugepaged/pages_to_scan

    sleep 30s
    lock_val "0" /sys/kernel/mm/transparent_hugepage/khugepaged/scan_sleep_millisecs
    while [ "$(cat /sys/kernel/mm/transparent_hugepage/khugepaged/full_scans)" -lt "10" ]; do
        sleep 1s
    done
    lock_val "6000" /sys/kernel/mm/transparent_hugepage/khugepaged/scan_sleep_millisecs
}

init_mem() {
    lmkd --reinit

    [ ! -f "/sys/module/pandora_config/parameters/enable_mm_vhs" ] && return

    mask_val "1" /proc/sys/vm/swappiness
    mask_val "20" /proc/sys/vm/compaction_proactiveness
    mask_val "0" /proc/sys/vm/page-cluster
    mask_val "65536" /proc/sys/vm/min_free_kbytes
    mask_val "150" /proc/sys/vm/watermark_scale_factor
    mask_val "15000" /proc/sys/vm/watermark_boost_factor
    mask_val "1" /proc/sys/vm/overcommit_memory
    mask_val "5" /proc/sys/vm/dirty_ratio
    mask_val "2" /proc/sys/vm/dirty_background_ratio
    mask_val "60" /proc/sys/vm/dirtytime_expire_seconds

    lock_val "Y" /sys/kernel/mm/lru_gen/enabled
    lock_val "1000" /sys/kernel/mm/lru_gen/min_ttl_ms
    lock_val "Y" /sys/module/pandora_config/parameters/enable_mm_vhs

    init_thp
}

init_android_config() {
    exec_system "device_config set_sync_disabled_for_tests until_reboot"
    exec_system "device_config put activity_manager max_cached_processes 65535"
    exec_system "device_config put activity_manager max_phantom_processes 65535"
    exec_system "device_config put lmkd_native use_minfree_levels false"
    exec_system "device_config delete lmkd_native thrashing_limit_critical"
    exec_system "device_config put activity_manager use_compaction false"
    # exec_system "device_config put activity_manager_native_boot use_freezer false"

    exec_system "settings put global settings_enable_monitor_phantom_procs false"
}

init_network() {
    mask_val "1" /proc/sys/net/ipv4/tcp_shrink_window
    mask_val "10" /proc/sys/net/ipv4/tcp_reordering
    mask_val "1000" /proc/sys/net/ipv4/tcp_max_reordering
    mask_val "1" /proc/sys/net/ipv4/tcp_thin_linear_timeouts
    mask_val "1048576" /proc/sys/net/ipv4/rmem_default
    mask_val "16777216" /proc/sys/net/ipv4/rmem_max
    mask_val "65536 1048576 16777216" /proc/sys/net/ipv4/tcp_rmem
    mask_val "1048576" /proc/sys/net/ipv4/wmem_default
    mask_val "16777216" /proc/sys/net/ipv4/wmem_max
    mask_val "65536 1048576 16777216" /proc/sys/net/ipv4/tcp_wmem
}

nohup sh "$MODDIR/fas_rs_mod.sh" >/dev/null 2>&1 &
wait_until_boot_complete
init_zram
wait_until_login
init_android_config
init_platform_config
init_brand_specific_config
init_network
init_mem
