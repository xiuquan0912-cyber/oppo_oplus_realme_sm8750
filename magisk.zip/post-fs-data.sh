#!/system/bin/sh

MODDIR=${0%/*}
MOD_DIR="$MODDIR/kernel_modules"

. "$MODDIR/utils.sh"

[ ! -f "/sys/module/oplus_bsp_game_opt" ] && insmod "$MOD_DIR"/oplus_bsp_game_opt.ko
if [ -f "/sys/module/pandora_config/parameters/enable_mm_vhs" ]; then
    insmod "$MOD_DIR/crypto_zstdp.ko"
    insmod "$MOD_DIR/crypto_lz4p.ko"
fi

"$MODDIR/bin/dsu_perf" -m 1
mask_val "" /proc/perfmgr_powerhal/ioctl_powerhal
