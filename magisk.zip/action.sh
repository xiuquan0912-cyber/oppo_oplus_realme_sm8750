#!/system/bin/sh

MODDIR=${0%/*}

. "$MODDIR/utils.sh"
STATSFILE=/dev/mount_masks/.boost_enabled
BUS_DIR="/sys/devices/system/cpu/bus_dcvs"

boost() {
    echo "- Boosting system..."

    #TempLimit Boost
    for i in /sys/class/thermal/t*; do
        grep -Eq "cpu|gpu" "$i/type" && lock_val_in_path "105000" "$i" "trip_point_2_temp"
    done

    # DCVS Boost
    lock_val_in_path "1" "$BUS_DIR/DDRQOS" "max_freq"
    lock_val "1" "$BUS_DIR/DDRQOS/boost_freq"
    lock_val_in_path "1" "$BUS_DIR/DDRQOS" "min_freq"

    #GPU Governor Boost
    lock_val "120" /sys/class/kgsl/kgsl-3d0/devfreq/mod_percent

    #UFS Boost
    mask_val "2147483646" /sys/class/devfreq/*ufs*/max_freq
    mask_val "2147483646" /sys/class/devfreq/*ufs*/min_freq

    #Boost end
    touch "$STATSFILE"
    echo "- Boosting system finished!"
}

deboost() {
    echo "- Deboosting system..."

    #TempLimit Boost
    for i in /sys/class/thermal/t*; do
        grep -Eq "cpu|gpu" "$i/type" && lock_val_in_path "100000" "$i" "trip_point_2_temp"
    done

    # DCVS Boost
    lock_val_in_path "0" "$BUS_DIR/DDRQOS" "min_freq"
    lock_val "0" "$BUS_DIR/DDRQOS/boost_freq"
    lock_val_in_path "0" "$BUS_DIR/DDRQOS" "max_freq"

    #GPU Governor Boost
    lock_val "100" /sys/class/kgsl/kgsl-3d0/devfreq/mod_percent

    #UFS Boost
    mask_val "2147483646" /sys/class/devfreq/*ufs*/max_freq
    mask_val "0" /sys/class/devfreq/*ufs*/min_freq

    #Deboost end
    rm -rf "$STATSFILE"
    echo "- Deboosting system finished!"
}

if [ -f "$STATSFILE" ]; then
    deboost 2>/dev/null
else
    boost 2>/dev/null
fi
